package org.example.ex41.base;
/*
 *  UCF COP3330 Fall 2021 Assignment 3 Solution
 *  Copyright 2021 Richard Nham
 */
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Solution41Test {

    @Test
    void main() {

    }
}